package com.example.deporte

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
